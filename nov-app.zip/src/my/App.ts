import { Component } from "@angular/core";

@Component({
    selector:'my-root',
    templateUrl:'./app.html',

})
export class App{

    name:string='ajay krishna';
    data:string='data in comp';

    recFromChild:String='yet to receive...';

    updateInfoFromChild(event){
            this.recFromChild=event;
    }
}