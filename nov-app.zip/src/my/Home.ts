import { Component, Input ,EventEmitter, Output} from "@angular/core";



@Component({
    selector:'home',
    template:`<h1>home page - welocme user-{{name}} {{age}} {{dataFromParent}}</h1>
    <button (click)="handle($event)">click to trigger</button>
    `,
    
})
export class Home{

    name:String='John Doe';
    age:number=45;
   @Input() dataFromParent:string;

    //child to parent communcn

    dataToParent:string='data shared from child'
    @Output() eventHandler:EventEmitter<String> = new EventEmitter<String>();

    handle($event){
        console.log('hi');
        this.eventHandler.emit(this.dataToParent);
    }



}

//string interpolation
/*
    data -in comp ----> displayed/kept/rendered to the DOM(browser /user)
    {{}} - interpolation symbol
*/
// prop binding - []
/*
mandatory usage when u use boolean values
*/
//event bidning ,
/* uses () for events in html 5 elements*/

/* using prop binding + event binding together is alternate way to 2 way 
binding  */
//two way binding
//sharing data between child and parent vice versa
