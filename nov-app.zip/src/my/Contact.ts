import { Component } from "@angular/core";

@Component({
    selector:'contact',
    template:`<h1> 
    contact page 
    <input type="text" [disabled]=isEnable/><br/>
    <input type='text' value={{content}} (keyup)="changeNameContent($event)"> ---- {{content}}
    <br/>
    <input type='text' [placeholder]=content1>
    </h1>`,
    
})
export class Contact{

    isEnable:boolean=false;
    content:String='enter name!!!'
    changeNameContent(event){
        console.log(event.target.value);
        console.log('called!!!');
        this.content=event.target.value;
    }
    content1:String='enter password'
}