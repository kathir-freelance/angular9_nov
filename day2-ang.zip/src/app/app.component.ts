import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  curr=4562.78345666
  jsObj={
    name:'default',
    age:12
  }
  today=new Date();
  title='Java Based APPLICATION'
  myStyle2={
    'color':'red',
    'background':'grey'
  }

    products:Product[]=[
      {pName:'bike',pId:19,qty:123},
      {pName:'plates',pId:18,qty:12},
      {pName:'mobiles',pId:17,qty:143},
      {pName:'charts',pId:16,qty:117},
      {pName:'toys',pId:15,qty:120},
      {pName:'laptops',pId:14,qty:1},
      {pName:'remote cars',pId:13,qty:13},
      {pName:'lantern',pId:11,qty:13},
    ]
    people: any[] = [
      {
        'state': 'Chennai',
        'people': [
          {
            "name": "david"
          },
          {
            "name": "Mike"
          },
        ]
      },
      {
        'state': 'Mumbai',
        'people': [
          {
            "name": "Pankaj"
          },
          {
            "name": "Akash"
          },
          {
            "name": "Ankit"
          }
        ]
      }
    ]; 
}

class Product{
  pName:String;
  pId:number;
  qty:number;
}